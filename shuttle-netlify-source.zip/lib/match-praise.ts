/** Outcome labels use the losing score scaled to the agreed target. */
export function matchPraise(own:number,other:number,target:15|21):string {
 const losing=Math.min(own,other)/target;
 const band=losing<=5/21?0:losing<=10/21?1:losing<=15/21?2:losing<=18/21?3:4;
 return (own>other?['对面真菜','豪情在天','习以为常','略施拳脚','差点吓尿']:['人菜瘾大','被上课了','还得再练','就差一点','让你两球'])[band];
}
