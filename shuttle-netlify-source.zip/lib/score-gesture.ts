export function scoreGesture(dx:number,dy:number,moved:boolean):'decrement'|'point'|'ignore'{
 if(dy < -45 && Math.abs(dy)>Math.abs(dx))return 'decrement';
 if(!moved && Math.hypot(dx,dy)<12)return 'point';
 return 'ignore';
}
