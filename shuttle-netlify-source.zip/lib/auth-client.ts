import { createAuthClient } from '@neondatabase/auth';
import { BetterAuthVanillaAdapter } from '@neondatabase/auth/vanilla/adapters';
// The host's auth bridge retains the managed session in an HttpOnly cookie.
const authUrl = new URL(PUBLIC_AUTH_URL, window.location.origin).href;
export const authClient = createAuthClient(authUrl, { adapter: BetterAuthVanillaAdapter() });
