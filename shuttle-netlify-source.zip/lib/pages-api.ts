import { authClient } from './auth-client';
import { actionSchema, mutate, type Action, type State } from './club';
export class Conflict extends Error {}
async function request(path: string, init: RequestInit = {}, authenticated = false) {
  // Neon puts its Data API JWT in the managed session, including refresh/caching.
  const token = authenticated ? (await authClient.getSession()).data?.session?.token : (await authClient.getAnonymousToken()).data?.token;
  if (authenticated && !token) throw new Error('登录已过期，请重新登录');
  const r = await fetch(PUBLIC_DATA_API_URL.replace(/\/$/,'') + path, {
    ...init, signal:init.signal ?? AbortSignal.timeout(20000), cache:'no-store', headers: { 'Content-Type':'application/json', ...(token ? {Authorization:`Bearer ${token}`} : {}), ...init.headers }
  });
  if (!r.ok) {
    if (r.status===409) throw new Conflict('战绩已在其他页面更新，请刷新后重试');
    if (r.status===401 || r.status===403) throw new Error('仅管理员可以修改战绩，请使用已绑定的邮箱登录');
    throw new Error('暂时无法连接战绩库，请稍后重试');
  }
  return r.json();
}
export async function loadClub() {
  const [rows,session] = await Promise.all([
    request('/club_state?id=eq.club&select=payload,revision'), authClient.getSession().catch(() => ({data:null}))
  ]);
  if (!rows.length) throw new Error('战绩库尚未初始化');
  const signedIn = Boolean(session.data?.user);
  let isOwner = false;
  let authIssue = '';
  if (signedIn) {
    try { isOwner = Boolean(await request('/rpc/club_is_owner', {method:'POST',body:'{}'},true)); if(!isOwner)authIssue='已登录，但管理员权限确认未通过。若使用的是管理员邮箱，请联系维护者检查权限绑定。'; }
    catch { authIssue = '暂时无法确认管理员身份，可重新登录；战绩仍可查看。'; }
  }
  return {state:rows[0].payload as State, revision:rows[0].revision as number, signedIn, isOwner, authIssue};
}
export async function saveClub(current: {state:State;revision:number}, action: Action) {
  const checked=actionSchema.parse(action);
  const state=mutate(current.state,checked,()=>crypto.getRandomValues(new Uint32Array(1))[0]/4294967296);
  const result = await request('/rpc/club_save', {method:'POST',body:JSON.stringify({expected_revision:current.revision,new_payload:state})},true);
  if (result?.conflict) throw new Conflict('战绩已在其他页面更新，请刷新后重试');
  return {state:result.payload as State,revision:result.revision as number,isOwner:true,signedIn:true};
}

// OTP success alone does not mean a usable session or owner permission exists.
export async function confirmAdminSignIn() {
 const session = await authClient.getSession({fetchOptions:{headers:{'X-Force-Fetch':'true'},signal:AbortSignal.timeout(20000)}});
 if(session.error)throw new Error('无法确认登录状态，请检查网络后重试。');
 if(!session.data?.user || !session.data?.session?.token)throw new Error('验证码已验证，但浏览器未保留登录状态。请在 Safari 普通窗口重新登录；若仍失败，请将此提示反馈给我。');
 const owner=await request('/rpc/club_is_owner',{method:'POST',body:'{}'},true);
 if(!owner)throw new Error('邮箱验证成功，但管理员权限确认未通过。请确认使用管理员邮箱；若邮箱正确，请联系维护者检查权限绑定。');
}
