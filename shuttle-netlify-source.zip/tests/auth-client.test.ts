import {test} from 'node:test';
import assert from 'node:assert/strict';
import auth from '../netlify/functions/auth.mjs';

test('auth bridge rejects cross-site writes and unknown paths before contacting Neon',async()=>{
 const old=globalThis.fetch; let calls=0;
 globalThis.fetch=async()=>{calls++;throw new Error('must not fetch');};
 try {
  const cross=await auth(new Request('https://club.netlify.app/api/auth/sign-out',{method:'POST',headers:{Origin:'https://other.invalid'}}));
  assert.equal(cross.status,403);
  assert.equal((await auth(new Request('https://club.netlify.app/api/auth/sign-out',{method:'POST'}))).status,403);
  assert.equal((await auth(new Request('https://club.netlify.app/api/auth/admin/delete-user'))).status,404);
  assert.equal(calls,0);
 } finally {globalThis.fetch=old;}
});
test('auth bridge preserves session cookies and deletion while making them host-only and private',async()=>{
 const old=globalThis.fetch; let received:Headers|undefined;
 globalThis.fetch=async(input,init)=>{
  assert.equal(String(input),'https://ep-holy-mode-b5qcgfo9.neonauth.c-7.us-east-2.aws.neon.tech/neondb/auth/get-session');
  received=new Headers(init?.headers);
  const headers=new Headers({'set-auth-jwt':'test-jwt'});
  headers.append('set-cookie','__Secure-neonauth.session_token=fake; Domain=neon.tech; Path=/neondb/auth; SameSite=None; HttpOnly; Secure');
  headers.append('set-cookie','old_session=; Max-Age=0; Path=/');
  return Response.json({session:{id:'test'},user:{id:'test'}},{headers});
 };
 try {
  const response=await auth(new Request('https://club.netlify.app/api/auth/get-session',{headers:{cookie:'__Secure-neonauth.session_token=fake'}}));
  assert.equal(received?.get('cookie'),'__Secure-neonauth.session_token=fake');
  assert.equal(received?.get('origin'),'https://club.netlify.app');
  const cookies=response.headers.getSetCookie();
  assert.equal(cookies.length,2);
  assert.ok(cookies.every(v=>!v.includes('Domain=')&&v.includes('Path=/')&&v.includes('SameSite=Lax')&&v.includes('Secure')&&v.includes('HttpOnly')));
  assert.match(cookies[1],/Max-Age=0/);
  assert.equal(response.headers.get('set-auth-jwt'),'test-jwt');
  assert.match(response.headers.get('Cache-Control')!,/no-store/);
 } finally {globalThis.fetch=old;}
});
