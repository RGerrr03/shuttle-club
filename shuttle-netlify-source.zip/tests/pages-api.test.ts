import { test } from 'node:test';
import assert from 'node:assert/strict';
import { build } from 'esbuild';
test('managed session JWT authorizes API; auth failures preserve public records', async()=>{
 const out=await build({entryPoints:['lib/pages-api.ts'],bundle:true,write:false,format:'esm',platform:'node',define:{PUBLIC_DATA_API_URL:'"https://test.invalid"'},plugins:[{name:'mock-auth',setup(b){b.onResolve({filter:/auth-client$/},()=>({path:'auth',namespace:'test'}));b.onLoad({filter:/.*/,namespace:'test'},()=>({contents:'export const authClient=globalThis.testAuth;'}));}}]});
 const state={players:[{id:'p1',name:'甲',active:true},{id:'p2',name:'乙',active:true}],sessions:[],matches:[],captains:[]};
 let jwt='test-session-jwt', deny=false, nonOwner=false, missingSession=false, forced=false;
 (globalThis as any).testAuth={getSession:async(options?:any)=>{if(options?.fetchOptions?.headers?.['X-Force-Fetch']==='true')forced=true;return {data:missingSession?null:{user:{id:'owner'},session:{token:jwt}}};},getAnonymousToken:async()=>({data:{token:'anonymous-test'}}),token:()=>{throw new Error('Legacy token endpoint must not be called');}};
 const previousFetch=globalThis.fetch;const seen:{path:string;authorization:string}[]=[];
 globalThis.fetch=async(input,init)=>{
  const path=String(input);const authorization=new Headers(init?.headers).get('Authorization')||'';seen.push({path,authorization});
  if(path.includes('/rpc/club_is_owner'))return new Response(JSON.stringify(!deny&&!nonOwner),{status:deny?403:200});
  if(path.includes('/rpc/club_save')){const body=JSON.parse(String(init?.body));return Response.json({payload:body.new_payload,revision:1});}
  return Response.json([{payload:state,revision:0}]);
 };
 try {
  const api=await import('data:text/javascript;base64,'+Buffer.from(out.outputFiles[0].text).toString('base64'));
  await api.confirmAdminSignIn();assert.equal(forced,true);
  missingSession=true;await assert.rejects(api.confirmAdminSignIn(),/未保留登录状态/);missingSession=false;
  nonOwner=true;await assert.rejects(api.confirmAdminSignIn(),/管理员权限确认未通过/);const wrongAccount=await api.loadClub();assert.ok(wrongAccount.authIssue);assert.equal(wrongAccount.isOwner,false);nonOwner=false;
  const loaded=await api.loadClub();assert.equal(loaded.isOwner,true);
  await api.saveClub(loaded,{type:'captains',ids:['p1','p2']});
  assert.ok(seen.filter(x=>x.path.includes('/rpc/')).every(x=>x.authorization==='Bearer test-session-jwt'));
  jwt='refreshed-session-jwt';await api.saveClub(loaded,{type:'captains',ids:['p1','p2']});assert.equal(seen.at(-1)?.authorization,'Bearer refreshed-session-jwt');
  deny=true;const readOnly=await api.loadClub();assert.equal(readOnly.isOwner,false);assert.equal(readOnly.state.players.length,2);assert.ok(readOnly.authIssue);
 } finally {globalThis.fetch=previousFetch;delete (globalThis as any).testAuth;}
});
