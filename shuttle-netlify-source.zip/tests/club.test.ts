import { strict as assert } from 'node:assert';
import { test } from 'node:test';
import { emptyState, mutate, standings, nextSessionTitle, normalizeRounds, type State, type Match } from '../lib/club.ts';
const base=():State=>({...emptyState(),players:Array.from({length:9},(_,i)=>({id:String(i),name:'球友'+i,active:true}))});
test('odd and even draws keep captains separate and preserve every participant',()=>{for(let n=2;n<=9;n++)for(let run=0;run<80;run++){const s=mutate(base(),{type:'draw',title:'测试球局',date:'2026-10-13',target:21,selected:Array.from({length:n},(_,i)=>String(i)),captains:['0','1']});const session=s.sessions[0];assert(session.a.includes('0'));assert(session.b.includes('1'));assert(!session.a.includes('1'));assert.equal(new Set([...session.a,...session.b]).size,n);assert(Math.abs(session.a.length-session.b.length)<=1);}});
test('a captain cannot be missing or duplicated',()=>{assert.throws(()=>mutate(base(),{type:'draw',title:'测试',date:'2026-10-13',target:15,selected:['0','2'],captains:['0','1']}));assert.throws(()=>mutate(base(),{type:'captains',ids:['0','0']}));});
const sessionState=():State=>({...base(),sessions:[{id:'session',date:'2026-10-13',title:'测试',target:21,a:['0','2','4','6'],b:['1','3','5','7'],captains:['0','1'],ended:false}]});
const match={type:'match' as const,id:'game',sessionId:'session',a:['0','2'],b:['1','3'],scoreA:21,scoreB:19,target:21 as const};
test('win rate only credits actual players and follows edits/deletion',()=>{let s=mutate(sessionState(),match);let ranks=standings(s,s.matches);assert.equal(ranks.length,4);assert.equal(ranks.find(p=>p.id==='0')?.rate,100);assert.equal(ranks.find(p=>p.id==='1')?.won,0);s=mutate(s,{...match,scoreA:19,scoreB:21});ranks=standings(s,s.matches);assert.equal(s.matches.length,1);assert.equal(ranks.find(p=>p.id==='1')?.rate,100);assert.equal(ranks.find(p=>p.id==='0')?.lost,1);s=mutate(s,{type:'deleteMatch',id:'game'});assert.equal(standings(s,s.matches).length,0);});
test('reject ties, incomplete scores, cross-team players and unequal sides',()=>{for(const override of [{scoreB:21},{scoreA:14,scoreB:12},{a:['1','2']},{a:['0']},{a:['0','0']}])assert.throws(()=>mutate(sessionState(),{...match,...override}));});
test('all three formats and 15-point games are supported',()=>{for(const n of [1,2,3]){const source=sessionState();const s=mutate(source,{...match,a:source.sessions[0].a.slice(0,n),b:source.sessions[0].b.slice(0,n),scoreA:15,scoreB:13,target:15});assert.equal(standings(s,s.matches).length,n*2);}});
test('ended sessions reject new games but allow correction of an existing game',()=>{let s=mutate(sessionState(),match);s=mutate(s,{type:'endSession',id:'session'});assert.throws(()=>mutate(s,{...match,id:'new'}));assert.doesNotThrow(()=>mutate(s,{...match,scoreB:17}));});
test('cancelled rounds release numbers and later rounds move forward',()=>{
 let s=mutate(base(),{type:'draw',title:'',date:'2026-10-14',target:21,selected:['0','1','2','3'],captains:['0','1']});
 const first=s.sessions[0].id;
 s=mutate(s,{type:'redraw',id:first});const second=s.sessions[0].id;
 assert.equal(s.sessions[0].title,'周赛02');
 s=mutate(s,{type:'endSession',id:second});assert.equal(nextSessionTitle(s),'周赛02');
 s=mutate(s,{type:'redraw',id:first});const third=s.sessions[0].id;
 assert.equal(s.sessions[0].title,'周赛02');
 s=mutate(s,{type:'endSession',id:first});assert.equal(s.sessions.find(x=>x.id===third)?.title,'周赛01');
 assert.equal(nextSessionTitle(s),'周赛02');
});
test('recording completes a round, retains results and permits editing',()=>{
 let s=mutate(sessionState(),match);
 assert.equal(s.sessions[0].ended,true);assert.equal(s.matches.length,1);
 assert.equal(nextSessionTitle(s),'周赛02');
 assert.throws(()=>mutate(s,{...match,id:'new-game'}));
 s=mutate(s,{...match,scoreB:17});assert.equal(s.matches[0].scoreB,17);
 s=mutate(s,{type:'deleteMatch',id:'game'});assert.equal(nextSessionTitle(s),'周赛01');
});
test('normalization migrates existing results and leaves source untouched',()=>{
 const original=sessionState();original.matches=[{...match,createdAt:'today'}];
 const result=normalizeRounds(original);
 assert.equal(result.sessions[0].ended,true);assert.equal(result.sessions[0].title,'周赛01');
 assert.equal(original.sessions[0].ended,false);assert.deepEqual(result.matches,original.matches);
});
