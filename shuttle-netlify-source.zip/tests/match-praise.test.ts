import {test} from 'node:test';
import assert from 'node:assert/strict';
import {matchPraise} from '../lib/match-praise.ts';
test('all ten outcome bands and boundaries',()=>{
 const wins=['对面真菜','轻松拿捏','实力在线','略胜一筹','极限拿下'];
 const losses=['人菜瘾大','被上课了','还得再练','就差一点','差点意思'];
 [[0,5],[6,10],[11,15],[16,18],[19,20]].forEach((scores,i)=>scores.forEach(score=>{
 assert.equal(matchPraise(21,score,21),wins[i]);
 assert.equal(matchPraise(score,21,21),losses[i]);
 }));
 assert.equal(matchPraise(24,22,21),'极限拿下');
 assert.equal(matchPraise(22,24,21),'差点意思');
});
test('15-point matches scale the same bands',()=>{
 [0,5,9,12,14].forEach((score,i)=>assert.equal(matchPraise(15,score,15),['对面真菜','轻松拿捏','实力在线','略胜一筹','极限拿下'][i]));
});
