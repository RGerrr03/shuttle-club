import { build } from 'esbuild';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
for(const key of ['PUBLIC_AUTH_URL','PUBLIC_DATA_API_URL'])if(!process.env[key])throw new Error(`Missing ${key}; configure verified public endpoints before publishing.`);
const r=await build({entryPoints:['app/main.tsx'],bundle:true,write:false,minify:true,format:'iife',jsx:'automatic',target:'es2022',define:{PUBLIC_AUTH_URL:JSON.stringify(process.env.PUBLIC_AUTH_URL),PUBLIC_DATA_API_URL:JSON.stringify(process.env.PUBLIC_DATA_API_URL),'process.env.NODE_ENV':'"production"'}});
const css=await readFile('app/globals.css','utf8');
await mkdir('dist',{recursive:true});
await writeFile('dist/index.html',`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title" content="羽球局"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><meta name="theme-color" content="#0c0f09"><meta name="referrer" content="strict-origin-when-cross-origin"><title>羽球局 · 每一分都算数</title><style>${css}</style></head><body><div id="root"></div><script>${r.outputFiles[0].text.replaceAll('</script','<\\/script')}</script></body></html>`);
console.log('Generated self-contained dist/index.html');
