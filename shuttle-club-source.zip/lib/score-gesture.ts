export function scoreGesture(dx:number,dy:number,moved:boolean):'adjust'|'point'|'ignore'{
 if(dy < -45 && Math.abs(dy)>Math.abs(dx))return 'adjust';
 if(!moved && Math.hypot(dx,dy)<12)return 'point';
 return 'ignore';
}
