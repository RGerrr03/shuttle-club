import { createAuthClient } from '@neondatabase/auth';
import { BetterAuthVanillaAdapter } from '@neondatabase/auth/vanilla/adapters';

// Auth's opaque bearer session supports iOS standalone browsers that reject
// cross-site cookies. Never use a Data API JWT as this session credential.
const sessionKey='shuttle-auth-session-v1';
let memorySession='';
export function clearAuthSession(){
 memorySession='';
 try{localStorage.removeItem(sessionKey);}catch{}
}
function sessionToken(){
 try{
  const raw=localStorage.getItem(sessionKey);
  if(raw){const stored=JSON.parse(raw);if(typeof stored.token==='string'&&stored.expiresAt>Date.now())return stored.token;clearAuthSession();}
 }catch{}
 return memorySession;
}
function rememberSession(token:string){
 memorySession=token;
 // Server validity/revocation remains authoritative. Bound local retention too.
 try{localStorage.setItem(sessionKey,JSON.stringify({token,expiresAt:Date.now()+7*24*60*60*1000}));}catch{}
}
export const authClient=createAuthClient(PUBLIC_AUTH_URL,{
 adapter:BetterAuthVanillaAdapter({fetchOptions:{
  onRequest(request){
   const token=sessionToken();
   if(token)request.headers.set('Authorization',`Bearer ${token}`);
  },
  onSuccess(ctx){
   const path=new URL(ctx.request.url).pathname;
   if(path.endsWith('/sign-out')){clearAuthSession();return;}
   const supplied=ctx.response.headers.get('set-auth-token');
   if(supplied)rememberSession(supplied);
   else if(path.endsWith('/sign-in/email-otp')&&typeof ctx.data?.token==='string')rememberSession(ctx.data.token);
   if(path.endsWith('/get-session')&&!ctx.data?.session)clearAuthSession();
  }
 }})
});
