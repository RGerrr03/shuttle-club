-- Run only after enabling Neon Data API (anonymous/authenticated roles + auth.user_id()).
-- Configure club_private.settings.admin_email separately using a parameterized query.
BEGIN;
CREATE SCHEMA IF NOT EXISTS club_private;
REVOKE ALL ON SCHEMA club_private FROM PUBLIC, anonymous, authenticated;
CREATE TABLE IF NOT EXISTS club_private.settings (id boolean PRIMARY KEY DEFAULT true CHECK(id), admin_email text NOT NULL);
REVOKE ALL ON club_private.settings FROM PUBLIC, anonymous, authenticated;
ALTER TABLE public.club_owner ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.club_owner FROM PUBLIC, anonymous, authenticated;
ALTER TABLE public.club_state ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.club_state FROM PUBLIC, anonymous, authenticated;
GRANT USAGE ON SCHEMA public TO anonymous, authenticated;
GRANT SELECT ON public.club_state TO anonymous, authenticated;
DROP POLICY IF EXISTS club_public_read ON public.club_state;
CREATE POLICY club_public_read ON public.club_state FOR SELECT TO anonymous, authenticated USING (id='club');

CREATE OR REPLACE FUNCTION public.club_is_owner() RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE uid text := auth.user_id(); bound text;
BEGIN
  IF uid IS NULL OR uid='' THEN RETURN false; END IF;
  IF NOT EXISTS(SELECT 1 FROM neon_auth."user" u WHERE u.id::text=uid AND u."emailVerified"=true AND coalesce(u.banned,false)=false) THEN RETURN false; END IF;
  SELECT user_id INTO bound FROM public.club_owner WHERE id='owner';
  IF bound IS NOT NULL THEN RETURN bound=uid; END IF;
  IF EXISTS(SELECT 1 FROM neon_auth."user" u JOIN club_private.settings c
    ON lower(u.email)=lower(c.admin_email)
    WHERE u.id::text=uid AND u."emailVerified"=true AND coalesce(u.banned,false)=false) THEN
    INSERT INTO public.club_owner(id,user_id) VALUES('owner',uid) ON CONFLICT DO NOTHING;
    SELECT user_id INTO bound FROM public.club_owner WHERE id='owner';
    RETURN bound=uid;
  END IF;
  RETURN false;
END;
$$;
REVOKE ALL ON FUNCTION public.club_is_owner() FROM PUBLIC, anonymous;
GRANT EXECUTE ON FUNCTION public.club_is_owner() TO authenticated;

CREATE OR REPLACE FUNCTION public.club_save(expected_revision integer,new_payload jsonb) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE row_revision integer;
BEGIN
  IF NOT public.club_is_owner() THEN RAISE EXCEPTION 'Only the club owner can save' USING ERRCODE='42501'; END IF;
  IF new_payload IS NULL OR jsonb_typeof(new_payload)<>'object'
    OR jsonb_typeof(new_payload->'players') IS DISTINCT FROM 'array'
    OR jsonb_typeof(new_payload->'sessions') IS DISTINCT FROM 'array'
    OR jsonb_typeof(new_payload->'matches') IS DISTINCT FROM 'array'
    OR jsonb_typeof(new_payload->'captains') IS DISTINCT FROM 'array'
    OR octet_length(new_payload::text)>5000000 THEN
      RAISE EXCEPTION 'Invalid club state' USING ERRCODE='22023';
  END IF;
  SELECT revision INTO row_revision FROM public.club_state WHERE id='club' FOR UPDATE;
  IF row_revision IS NULL OR row_revision IS DISTINCT FROM expected_revision THEN RETURN jsonb_build_object('conflict',true); END IF;
  UPDATE public.club_state SET payload=new_payload,revision=revision+1 WHERE id='club';
  RETURN jsonb_build_object('payload',new_payload,'revision',row_revision+1);
END;
$$;
REVOKE ALL ON FUNCTION public.club_save(integer,jsonb) FROM PUBLIC, anonymous;
GRANT EXECUTE ON FUNCTION public.club_save(integer,jsonb) TO authenticated;
COMMIT;
NOTIFY pgrst,'reload schema';
