> 迁移状态：本目录为原运行版本的源码归档。此 GitHub 版本尚未配置发布流水线；Cloudflare D1 与 Sites 身份验证须按目标部署环境适配。以下文档中的 Sites 运行说明仅适用于原环境。

# 羽球局 · Shuttle Club

共享羽毛球战绩页，使用 Sites / Vinext / Cloudflare D1。

## 使用

1. 管理员使用绑定的 ChatGPT 账号登录，添加常用球友。
2. 发起球局：选到场名单、日期、15 或 21 分；指定两位固定选手并抽签。
3. A / B 队在当前球局固定，每场从两队选取 1、2 或 3 名上场球友。
4. 直接录入结果，或打开横屏记分板；加减分、撤销、交换左右后结束保存。
5. 战绩自动计算，支持按球局、赛制、时间筛选及 CSV 导出。管理员可修正或删除结果。
6. 结束球局后可发起下一次抽签。

## 权限

公开页面允许只读访问，写入接口使用 Sites 的 ChatGPT 登录身份。
上线时在 Sites 环境变量中配置 secret `ADMIN_EMAIL`。
第一次通过指定邮箱校验的写入将绑定稳定的站点用户 ID；之后按此 ID 授权。
邮箱及用户 ID 不会在公开 API 返回。未配置邮箱时所有访客均只读。

正式数据保存在 D1；比分草稿暂存在当前设备。公开列表每 30 秒自动同步。
数据修改采用版本校验，避免多页面覆盖。

## 开发

Node >= 22.13。依赖与构建使用 Sites 插件提供的 scripts。
本地 `.dev.vars`（忽略，不上传）可使用 `ADMIN_EMAIL=seedy@sites.test` 测试预览登录。
本地数据库与线上数据库隔离。

检查：`node --test tests/club.test.ts`、`node node_modules/typescript/bin/tsc --noEmit`。
`tests/api-check.mjs` 用于已登录过且已有测试数据的本地 5173 端口，验证权限和版本冲突。
