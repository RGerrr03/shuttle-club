import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '../../chatgpt-auth';
import { actionSchema, emptyState, mutate, type State } from '../../../lib/club';
export const dynamic = 'force-dynamic';
const json = (value: unknown, status=200) => Response.json(value,{status,headers:{'Cache-Control':'no-store'}});
async function isOwner() {
  const user=await getChatGPTUser(); if(!user) return false;
  const bound=await env.DB!.prepare('SELECT user_id FROM club_owner WHERE id = ?').bind('owner').first<{user_id:string}>();
  if(bound) return bound.user_id===user.userId;
  const expected=(env as unknown as {ADMIN_EMAIL?:string}).ADMIN_EMAIL?.trim().toLowerCase();
  return Boolean(expected && user.email.toLowerCase()===expected);
}
export async function GET() {
  try { const owner=await isOwner(); const row=await env.DB!.prepare('SELECT payload, revision FROM club_state WHERE id = ?').bind('club').first<{payload:string;revision:number}>();
  return json({state:row?JSON.parse(row.payload):emptyState(),revision:row?.revision??0,isOwner:owner,signedIn:Boolean(await getChatGPTUser())});
  } catch {return json({error:'暂时无法连接战绩库，请稍后刷新'},503);}
}
export async function POST(request: Request) {
  try {
    const origin=request.headers.get('origin');if(!origin||origin!==new URL(request.url).origin)return json({error:'请求来源无效'},403);
    if(!(await isOwner()))return json({error:'仅管理员可以修改战绩，请使用已绑定的 ChatGPT 账号登录'},403);
    const body=await request.json() as {revision:number;action:unknown};
    if(!body||!Number.isInteger(body.revision)||body.revision<0)return json({error:'版本信息无效'},400);
    const parsed=actionSchema.safeParse(body.action);if(!parsed.success)return json({error:'请检查输入内容'},400);
    const user=await getChatGPTUser();
    await env.DB!.prepare('INSERT OR IGNORE INTO club_owner (id,user_id) VALUES (?,?)').bind('owner',user!.userId).run();
    if(!(await isOwner()))return json({error:'此账号不是管理员'},403);
    await env.DB!.prepare('INSERT OR IGNORE INTO club_state (id,payload,revision) VALUES (?,?,0)').bind('club',JSON.stringify(emptyState())).run();
    const row=await env.DB!.prepare('SELECT payload, revision FROM club_state WHERE id = ?').bind('club').first<{payload:string;revision:number}>();
    if(row!.revision!==body.revision)return json({error:'战绩已在其他页面更新，请刷新后重试'},409);
    let state:State;try{state=mutate(JSON.parse(row!.payload),parsed.data,()=>crypto.getRandomValues(new Uint32Array(1))[0]/4294967296);}catch(e){return json({error:(e as Error).message},400);}
    const result=await env.DB!.prepare('UPDATE club_state SET payload=?,revision=revision+1 WHERE id=? AND revision=?').bind(JSON.stringify(state),'club',body.revision).run();
    if(result.meta.changes!==1)return json({error:'战绩已在其他页面更新，请刷新后重试'},409);
    return json({state,revision:body.revision+1,isOwner:true,signedIn:true});
  }catch{return json({error:'保存失败，请检查网络后重试；当前输入仍保留'},503);}
}
