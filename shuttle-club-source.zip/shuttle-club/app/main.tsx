import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import Club from './club';
import SignIn from './sign-in';
import SignOut from './sign-out';
function App() {
 const [route,setRoute]=useState(window.location.hash);
 useEffect(()=>{const change=()=>setRoute(window.location.hash);window.addEventListener('hashchange',change);return()=>window.removeEventListener('hashchange',change);},[]);
 return route==='#/sign-in'?<SignIn/>:route==='#/sign-out'?<SignOut/>:<Club/>;
}
createRoot(document.getElementById('root')!).render(<App/>);
