import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {title:'羽球局 · 每一分都算数',description:'从赛前抽签到赛后战绩，记住每一次好球。',icons:{icon:'/favicon.svg'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="zh-CN"><body>{children}</body></html>}
