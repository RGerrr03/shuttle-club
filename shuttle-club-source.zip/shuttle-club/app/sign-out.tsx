"use client";
import { useState } from 'react';
import { authClient } from '../lib/auth-client';
export default function SignOut() {
  const [error,setError] = useState('');
  const [busy,setBusy] = useState(false);
  return <main className="auth-shell"><section className="auth-card"><h1>退出管理员</h1><p>退出后仍可以查看公开战绩。</p><button className="primary-btn" disabled={busy} onClick={async()=>{setBusy(true);try {const r=await authClient.signOut();if(r.error)throw new Error();window.location.hash='/';}catch{setError('退出失败，请重试');setBusy(false);}}}>{busy?'请稍候…':'确认退出'}</button>{error&&<p role="alert">{error}</p>}<a href="#/">返回战绩</a></section></main>;
}
