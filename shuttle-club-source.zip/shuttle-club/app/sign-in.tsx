"use client";
import { useState } from 'react';
import { authClient } from '../lib/auth-client';
export default function SignIn() {
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  async function submit(event: React.FormEvent) {
    event.preventDefault(); setBusy(true); setError('');
    try {
      if (!sent) {
        const result = await authClient.emailOtp.sendVerificationOtp({ email: email.trim(), type: 'sign-in' });
        if (result.error) throw new Error(result.error.message || '验证码发送失败，请稍后重试');
        setSent(true);
      } else {
        const result = await authClient.signIn.emailOtp({ email: email.trim(), otp: otp.trim() });
        if (result.error) throw new Error(result.error.message || '验证码无效，请重新输入');
        window.location.hash='/';
      }
    } catch (e) { setError(e instanceof Error ? e.message : '暂时无法登录，请重试'); }
    finally { setBusy(false); }
  }
  return <main className="auth-shell"><section className="auth-card"><a href="#/" className="eyebrow">羽球局 · 返回战绩</a><h1>管理员登录</h1><p>球友无需登录即可查看。使用管理员邮箱接收验证码，登录后可抽签和录入比分。</p><form onSubmit={submit}><label>邮箱<input type="email" autoComplete="email" required value={email} disabled={sent || busy} onChange={e=>setEmail(e.target.value)}/></label>{sent && <label>邮箱验证码<input inputMode="numeric" autoComplete="one-time-code" required value={otp} onChange={e=>setOtp(e.target.value)} autoFocus/></label>}{error && <p className="auth-error" role="alert">{error}</p>}<button className="primary-btn" disabled={busy}>{busy ? '请稍候…' : sent ? '登录' : '发送验证码'}</button>{sent && <><p role="status">验证码已发送，请查看收件箱及垃圾邮件。</p><button type="button" className="text-btn" disabled={busy} onClick={()=>{setSent(false);setOtp('');setError('');}}>更换邮箱 / 重新发送</button></>}</form></section></main>;
}
