import { z } from 'zod';
export type Player = { id: string; name: string; active: boolean };
export type Session = { id: string; date: string; title: string; target: 15 | 21; a: string[]; b: string[]; captains: string[]; ended: boolean };
export type Match = { id: string; sessionId: string; a: string[]; b: string[]; scoreA: number; scoreB: number; target: 15 | 21; createdAt: string };
export type State = { players: Player[]; sessions: Session[]; matches: Match[]; captains: string[] };
export const initialPlayers: Player[] = ['罗成玉','范家希','吕晴','曹爱周','武浩楠','李宇峰','加瑞哲'].map((name,index)=>({id:`club-player-${index+1}`,name,active:true}));
export const emptyState = (): State => ({ players: initialPlayers.map(p=>({...p})), sessions: [], matches: [], captains: [] });
const id = z.string().min(1).max(80);
const pair = z.array(id).length(2);
const target = z.union([z.literal(15), z.literal(21)]);
const matchFields = { sessionId: id, a: z.array(id).min(1).max(3), b: z.array(id).min(1).max(3), scoreA: z.number().int().min(0).max(999), scoreB: z.number().int().min(0).max(999), target };
export const actionSchema = z.discriminatedUnion('type', [
  z.object({ type: z.literal('addPlayer'), name: z.string().trim().min(1).max(20) }),
  z.object({ type: z.literal('editPlayer'), id, name: z.string().trim().min(1).max(20), active: z.boolean() }),
  z.object({ type: z.literal('captains'), ids: pair }),
  z.object({ type: z.literal('draw'), title: z.string().trim().min(1).max(40), date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), target, selected: z.array(id).min(2).max(100), captains: pair }),
  z.object({ type: z.literal('endSession'), id }),
  z.object({ type: z.literal('match'), id, ...matchFields }),
  z.object({ type: z.literal('deleteMatch'), id }),
]);
export type Action = z.infer<typeof actionSchema>;
export function shuffle<T>(values: T[], random = Math.random): T[] { const out = [...values]; for(let i=out.length-1;i>0;i--){ const j=Math.floor(random()*(i+1)); [out[i],out[j]]=[out[j],out[i]]; } return out; }
export function mutate(original: State, action: Action, random = Math.random): State {
  const s: State = structuredClone(original);
  const fail = (message: string): never => { throw new Error(message); };
  const active = (pid: string) => s.players.some(p=>p.id===pid && p.active);
  if(action.type==='addPlayer') { if(s.players.some(p=>p.name===action.name)) fail('这个昵称已存在'); s.players.push({id:crypto.randomUUID(),name:action.name,active:true}); }
  if(action.type==='editPlayer') { const p=s.players.find(p=>p.id===action.id); if(!p) fail('选手不存在'); if(s.players.some(p=>p.id!==action.id&&p.name===action.name)) fail('这个昵称已存在'); p!.name=action.name;p!.active=action.active; }
  if(action.type==='captains'||action.type==='draw') { const ids=action.type==='captains'?action.ids:action.captains; if(new Set(ids).size!==2||!ids.every(active)) fail('请选择两位不同的在册固定选手'); s.captains=ids; }
  if(action.type==='draw') {
    if(new Set(action.selected).size!==action.selected.length || !action.selected.every(active)) fail('到场选手无效');
    if(!action.captains.every(p=>action.selected.includes(p))) fail('两位固定选手都需要到场');
    if(s.sessions.some(x=>!x.ended)) fail('请先结束当前球局');
    if(Number.isNaN(Date.parse(action.date+'T12:00:00'))) fail('日期无效');
    const rest=shuffle(action.selected.filter(p=>!action.captains.includes(p)),random);
    const a=[action.captains[0]],b=[action.captains[1]],offset=random()<0.5?0:1;
    rest.forEach((p,i)=>((i+offset)%2===0?a:b).push(p));
    s.sessions.unshift({id:crypto.randomUUID(),date:action.date,title:action.title,target:action.target,a,b,captains:action.captains,ended:false});
  }
  if(action.type==='endSession') {const session=s.sessions.find(x=>x.id===action.id);if(!session)fail('球局不存在');session!.ended=true;}
  if(action.type==='match') {
    const session=s.sessions.find(x=>x.id===action.sessionId); if(!session)fail('球局不存在');
    const existing=s.matches.find(m=>m.id===action.id);
    if(existing&&existing.sessionId!==action.sessionId)fail('不能更改比赛所属球局');
    if(!existing&&session!.ended)fail('球局已结束，请新建球局');
    if(action.a.length!==action.b.length||new Set([...action.a,...action.b]).size!==action.a.length+action.b.length)fail('双方人数需要一致，且选手不可重复');
    if(!action.a.every(p=>session!.a.includes(p))||!action.b.every(p=>session!.b.includes(p)))fail('上场选手必须属于对应的固定队伍');
    if(action.scoreA===action.scoreB)fail('比赛不能以平分结束');
    if(Math.max(action.scoreA,action.scoreB)<action.target)fail('胜方分数尚未达到目标分');
    const match: Match={id:action.id,sessionId:action.sessionId,a:action.a,b:action.b,scoreA:action.scoreA,scoreB:action.scoreB,target:action.target,createdAt:existing?.createdAt??new Date().toISOString()};
    if(existing)s.matches[s.matches.indexOf(existing)]=match;else s.matches.unshift(match);
  }
  if(action.type==='deleteMatch') { if(!s.matches.some(m=>m.id===action.id))fail('比赛不存在');s.matches=s.matches.filter(m=>m.id!==action.id); }
  return s;
}
export function standings(s: State, matches: Match[]) { return s.players.map(p=>{const played=matches.filter(m=>[...m.a,...m.b].includes(p.id));const won=played.filter(m=>m.a.includes(p.id)?m.scoreA>m.scoreB:m.scoreB>m.scoreA).length;return {...p,played:played.length,won,lost:played.length-won,rate:played.length?Math.round(won/played.length*100):0};}).filter(p=>p.played>0).sort((a,b)=>b.rate-a.rate||b.won-a.won||b.played-a.played||a.name.localeCompare(b.name)); }
