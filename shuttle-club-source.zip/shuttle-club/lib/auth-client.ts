import { createAuthClient } from '@neondatabase/auth';
export const authClient = createAuthClient(PUBLIC_AUTH_URL);
