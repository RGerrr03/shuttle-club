declare const PUBLIC_AUTH_URL: string;
declare const PUBLIC_DATA_API_URL: string;
