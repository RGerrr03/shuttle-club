import { authClient } from './auth-client';
import { actionSchema, mutate, type Action, type State } from './club';
export class Conflict extends Error {}
async function request(path: string, init: RequestInit = {}, authenticated = false) {
  const token = authenticated ? (await authClient.token()).data?.token : (await authClient.getAnonymousToken()).data?.token;
  if (authenticated && !token) throw new Error('登录已过期，请重新登录');
  const r = await fetch(PUBLIC_DATA_API_URL.replace(/\/$/,'') + path, {
    ...init, cache:'no-store', headers: { 'Content-Type':'application/json', ...(token ? {Authorization:`Bearer ${token}`} : {}), ...init.headers }
  });
  if (!r.ok) {
    if (r.status===409) throw new Conflict('战绩已在其他页面更新，请刷新后重试');
    if (r.status===401 || r.status===403) throw new Error('仅管理员可以修改战绩，请使用已绑定的邮箱登录');
    throw new Error('暂时无法连接战绩库，请稍后重试');
  }
  return r.json();
}
export async function loadClub() {
  const [rows,session] = await Promise.all([
    request('/club_state?id=eq.club&select=payload,revision'), authClient.getSession().catch(() => ({data:null}))
  ]);
  if (!rows.length) throw new Error('战绩库尚未初始化');
  const signedIn = Boolean(session.data?.user);
  const isOwner = signedIn ? await request('/rpc/club_is_owner', {method:'POST',body:'{}'},true) : false;
  return {state:rows[0].payload as State, revision:rows[0].revision as number, signedIn, isOwner:Boolean(isOwner)};
}
export async function saveClub(current: {state:State;revision:number}, action: Action) {
  const checked=actionSchema.parse(action);
  const state=mutate(current.state,checked,()=>crypto.getRandomValues(new Uint32Array(1))[0]/4294967296);
  const result = await request('/rpc/club_save', {method:'POST',body:JSON.stringify({expected_revision:current.revision,new_payload:state})},true);
  if (result?.conflict) throw new Conflict('战绩已在其他页面更新，请刷新后重试');
  return {state:result.payload as State,revision:result.revision as number,isOwner:true,signedIn:true};
}
