import {test} from 'node:test';
import assert from 'node:assert/strict';
import {build} from 'esbuild';
test('cookie-free login sends opaque bearer session, renews JWT and clears credentials on sign-out',async()=>{
 const out=await build({entryPoints:['lib/auth-client.ts'],bundle:true,write:false,format:'esm',platform:'node',define:{PUBLIC_AUTH_URL:'"https://auth.test.invalid/auth"'}});
 const store=new Map<string,string>();
 const previousStorage=Object.getOwnPropertyDescriptor(globalThis,'localStorage');
 Object.defineProperty(globalThis,'localStorage',{configurable:true,value:{getItem:(k:string)=>store.get(k)??null,setItem:(k:string,v:string)=>store.set(k,v),removeItem:(k:string)=>store.delete(k)}});
 const oldFetch=globalThis.fetch;const seen:{path:string;auth:string|null}[]=[];
 const user={id:'test-owner',email:'test@example.invalid',emailVerified:true,name:'Test',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};
 globalThis.fetch=async(input,init)=>{
  const path=new URL(String(input)).pathname,auth=new Headers(init?.headers).get('Authorization');seen.push({path,auth});
  if(path.endsWith('/sign-in/email-otp'))return Response.json({token:'opaque-test-session',user},{headers:{'set-auth-token':'signed-test-session'}});
  if(path.endsWith('/get-session'))return auth==='Bearer signed-test-session'?Response.json({session:{id:'s1',userId:user.id,token:'opaque-test-session',expiresAt:new Date(Date.now()+3600000).toISOString()},user},{headers:{'set-auth-jwt':'test-data-api-jwt'}}):Response.json(null);
  if(path.endsWith('/sign-out'))return Response.json({success:true});
  throw new Error('Unexpected auth request '+path);
 };
 try{
  const {authClient}=await import('data:text/javascript;base64,'+Buffer.from(out.outputFiles[0].text).toString('base64'));
  await authClient.signIn.emailOtp({email:user.email,otp:'test-code'});
  const session=await authClient.getSession({fetchOptions:{headers:{'X-Force-Fetch':'true'}}});
  assert.equal(session.data?.user.id,user.id);assert.equal(session.data?.session.token,'test-data-api-jwt');
  assert.equal(seen.find(x=>x.path.endsWith('/get-session'))?.auth,'Bearer signed-test-session');
  assert.ok([...store.values()].every(v=>!v.includes('test-data-api-jwt')));
  await authClient.signOut();assert.equal(store.size,0);
  await authClient.getSession({fetchOptions:{headers:{'X-Force-Fetch':'true'}}});assert.equal(seen.at(-1)?.auth,null);
 }finally{globalThis.fetch=oldFetch;if(previousStorage)Object.defineProperty(globalThis,'localStorage',previousStorage);else delete (globalThis as any).localStorage;}
});
