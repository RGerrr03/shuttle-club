import {test} from 'node:test';
import assert from 'node:assert/strict';
import {scoreGesture} from '../lib/score-gesture.ts';
test('tap adds once; upward swipe adjusts without adding; other drags are ignored',()=>{
 assert.equal(scoreGesture(2,3,false),'point');
 assert.equal(scoreGesture(4,-90,true),'adjust');
 assert.equal(scoreGesture(4,90,true),'ignore');
 assert.equal(scoreGesture(90,-50,true),'ignore');
 assert.equal(scoreGesture(0,0,true),'ignore');
 assert.equal(scoreGesture(0,-30,true),'ignore');
});
